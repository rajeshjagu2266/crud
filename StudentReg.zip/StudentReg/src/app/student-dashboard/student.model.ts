export class StudentModel{
    id:number=0;
    name:string="";
    class:string="";
    address:string="";
    email:string="";
    city:string="";
    password:string=""
}